const mysql = require("mysql");

const pool = mysql.createPool({
  host: "api.wonderfullindonesia.my.id",
  user: "wonderfu_admin",
  password: "Mok$Lff}dZ7C",
  database: "wonderfu_destinasi",
});

module.exports = pool;
